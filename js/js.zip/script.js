// function popupContent() {
//     $('[data-init="magnificPopup"]').each(function(t, a) {
//         var e = $(this),
//             o = {
//                 removalDelay: 500,
//                 callbacks: {
//                     beforeOpen: function() {
//                         this.st.mainClass = this.st.el.attr("data-effect")
//                     }
//                 },
//                 midClick: !0
//             },
//             s = $.extend(!0, o, e.data("options"));
//         e.magnificPopup(s)
//     }), $(".gallery-item").length > 0 && $(".gallery-item").magnificPopup({
//         gallery: {
//             enabled: !0
//         }
//     }), $(".quick-view").length > 0 && $(".quick-view").magnificPopup({
//         type: "ajax"
//     }), $(".popup-youtube").magnificPopup({
//         type: "iframe"
//     })
// }

// function googleMap() {
//     function t() {
//         var t = {
//                 center: a,
//                 zoom: 16,
//                 scrollwheel: !1,
//                 mapTypeControlOptions: {
//                     mapTypeIds: [google.maps.MapTypeId.ROADMAP, "map_style"]
//                 }
//             },
//             o = new google.maps.Map(document.getElementById("googleMap"), t),
//             s = new google.maps.Marker({
//                 position: e,
//                 icon: $obj.data("icon")
//             });
//         s.setMap(o)
//     }

//     function t() {
//         var t = {
//                 center: a,
//                 zoom: 16,
//                 scrollwheel: !1,
//                 mapTypeControlOptions: {
//                     mapTypeIds: [google.maps.MapTypeId.ROADMAP, "map_style"]
//                 }
//             },
//             o = new google.maps.Map(document.getElementById("googleMap2"), t),
//             s = new google.maps.Marker({
//                 position: e,
//                 icon: $obj.data("icon")
//             });
//         s.setMap(o)
//     }
//     if ($("#googleMap").length > 0) {
//         $obj = $("#googleMap");
//         var a = new google.maps.LatLng($obj.data("lat"), $obj.data("lon")),
//             e = new google.maps.LatLng($obj.data("lat"), $obj.data("lon"));
//         google.maps.event.addDomListener(window, "load", t)
//     }
//     if ($("#googleMap2").length > 0) {
//         $obj = $("#googleMap2");
//         var a = new google.maps.LatLng($obj.data("lat"), $obj.data("lon")),
//             e = new google.maps.LatLng($obj.data("lat"), $obj.data("lon"));
//         google.maps.event.addDomListener(window, "load", t)
//     }
// }

function introHeight() {
    var t = $(window).height();
    $(".section-fullscreen").css({
        height: t
    }), $(".fullheight").css({
        height: t
    })
}

function toggleMenu() {
    $(".menu-header3").on("click", function() {
        $(this).toggleClass("open"), $(".navbar").toggleClass("open")
    })
}

function progressBar() {
    $(".block-progressbar").each(function() {
        $(this).find(".progressbar").progressbar({
            display_text: "center"
        }), $(this).find(".progressbar").css("background-color", $(this).attr("data-color"))
    })
}

function owlCarousel() {
    $(".agent-carousel").length > 0 && $(".agent-carousel").each(function() {
        var t = "true" === $(this).attr("data-auto-play") ? !0 : !1;
        $(this).owlCarousel({
            items: $(this).attr("data-desktop"),
            loop: !0,
            mouseDrag: !0,
            navigation: !0,
            dots: !1,
            pagination: !1,
            autoPlay: t,
            autoplayTimeout: 5e3,
            autoplayHoverPause: !0,
            smartSpeed: 1e3,
            autoplayHoverPause: !0,
            navigationText: ['<i class="prev-agent ion-ios-arrow-left"></i>', '<i class="next-agent ion-ios-arrow-right"></i>'],
            itemsDesktop: [1199, $(this).attr("data-desktop")],
            itemsDesktopSmall: [979, $(this).attr("data-laptop")],
            itemsTablet: [768, $(this).attr("data-tablet")],
            itemsMobile: [479, $(this).attr("data-mobile")]
        })
    }), $(".testimonial-carousel").length > 0 && $(".testimonial-carousel").each(function() {
        var t = "true" === $(this).attr("data-auto-play") ? !0 : !1;
        $(this).owlCarousel({
            items: $(this).attr("data-desktop"),
            loop: !0,
            mouseDrag: !0,
            navigation: !1,
            dots: !1,
            pagination: !0,
            autoPlay: t,
             autoHeight:true,
            autoplayTimeout: 800,
            autoplayHoverPause: !0,
            smartSpeed: 1e3,
            autoplayHoverPause: !0,
            itemsDesktop: [1199, $(this).attr("data-desktop")],
            itemsDesktopSmall: [979, $(this).attr("data-laptop")],
            itemsTablet: [768, $(this).attr("data-tablet")],
            itemsMobile: [479, $(this).attr("data-mobile")]
        })
    }), $(".partner-carousel").length > 0 && $(".partner-carousel").each(function() {
        var t = "true" === $(this).attr("data-auto-play") ? !0 : !1;
        $(this).owlCarousel({
            items: $(this).attr("data-desktop"),
            loop: !0,
            mouseDrag: !0,
            navigation: !0,
            dots: !1,
            pagination: !1,
            autoPlay: t,
            autoplayTimeout: 800,
            autoplayHoverPause: !0,
            smartSpeed: 1e3,
            autoplayHoverPause: !0,
            navigationText: ['<i class="prev-agent ion-ios-arrow-left"></i>', '<i class="next-agent ion-ios-arrow-right"></i>'],
            itemsDesktop: [1199, $(this).attr("data-desktop")],
            itemsDesktopSmall: [979, $(this).attr("data-laptop")],
            itemsTablet: [768, $(this).attr("data-tablet")],
            itemsMobile: [479, $(this).attr("data-mobile")]
        })
    }), $(".properties-carousel").length > 0 && $(".properties-carousel").each(function() {
        var t = "true" === $(this).attr("data-auto-play") ? !0 : !1;
        $(this).owlCarousel({
            items: $(this).attr("data-desktop"),
            loop: !0,
            mouseDrag: !0,
            navigation: !0,
            dots: !1,
            pagination: !1,
            autoPlay: t,
            autoplayTimeout: 5e3,
            autoplayHoverPause: !0,
            smartSpeed: 1e3,
            autoplayHoverPause: !0,
            navigationText: ['<i class="prev-agent ion-ios-arrow-left"></i>', '<i class="next-agent ion-ios-arrow-right"></i>'],
            itemsDesktop: [1199, $(this).attr("data-desktop")],
            itemsDesktopSmall: [979, $(this).attr("data-laptop")],
            itemsTablet: [768, $(this).attr("data-tablet")],
            itemsMobile: [479, $(this).attr("data-mobile")]
        })
    }), $(".properties-carousel-2").length > 0 && $(".properties-carousel-2").each(function() {
        var t = "true" === $(this).attr("data-auto-play") ? !0 : !1;
        $(this).owlCarousel({
            items: $(this).attr("data-desktop"),
            loop: !0,
            mouseDrag: !0,
            navigation: !1,
            dots: !0,
            pagination: !0,
            autoPlay: t,
            autoplayTimeout: 5e3,
            autoplayHoverPause: !0,
            smartSpeed: 1e3,
            autoplayHoverPause: !0,
            itemsDesktop: [1199, $(this).attr("data-desktop")],
            itemsDesktopSmall: [979, $(this).attr("data-laptop")],
            itemsTablet: [768, $(this).attr("data-tablet")],
            itemsMobile: [479, $(this).attr("data-mobile")]
        })
    }), $(".property-detail-carousel").length > 0 && $(".property-detail-carousel").each(function() {
        var t = "true" === $(this).attr("data-auto-play") ? !0 : !1;
        $(this).owlCarousel({
            items: $(this).attr("data-desktop"),
            loop: !0,
            mouseDrag: !0,
            navigation: !1,
            dots: !0,
            pagination: !0,
            autoPlay: t,
            autoplayTimeout: 5e3,
            autoplayHoverPause: !0,
            smartSpeed: 1e3,
            autoplayHoverPause: !0,
            afterInit: makePages,
            afterUpdate: makePages,
            itemsDesktop: [1199, $(this).attr("data-desktop")],
            itemsDesktopSmall: [979, $(this).attr("data-laptop")],
            itemsTablet: [768, $(this).attr("data-tablet")],
            itemsMobile: [479, $(this).attr("data-mobile")]
        })
    }), $(".blog-carousel").length > 0 && $(".blog-carousel").each(function() {
        var t = "true" === $(this).attr("data-auto-play") ? !0 : !1;
        $(this).owlCarousel({
            items: $(this).attr("data-desktop"),
            loop: !0,
            mouseDrag: !0,
            navigation: !0,
            dots: !1,
            pagination: !1,
            autoPlay: t,
            autoplayTimeout: 5e3,
            autoplayHoverPause: !0,
            smartSpeed: 1e3,
            autoplayHoverPause: !0,
            navigationText: ['<i class="prev-agent ion-ios-arrow-left"></i>', '<i class="next-agent ion-ios-arrow-right"></i>'],
            itemsDesktop: [1199, $(this).attr("data-desktop")],
            itemsDesktopSmall: [979, $(this).attr("data-laptop")],
            itemsTablet: [768, $(this).attr("data-tablet")],
            itemsMobile: [479, $(this).attr("data-mobile")]
        })
    }), $(".floor-plan-carousel").length > 0 && $(".floor-plan-carousel").each(function() {
        var t = "true" === $(this).attr("data-auto-play") ? !0 : !1;
        $(this).owlCarousel({
            items: $(this).attr("data-desktop"),
            loop: !0,
            mouseDrag: !0,
            navigation: !0,
            dots: !1,
            pagination: !1,
            autoPlay: t,
            autoplayTimeout: 5e3,
            autoplayHoverPause: !0,
            smartSpeed: 1e3,
            autoplayHoverPause: !0,
            navigationText: ['<i class="prev ion-ios-arrow-left"></i>', '<i class="next ion-ios-arrow-right"></i>'],
            itemsDesktop: [1199, $(this).attr("data-desktop")],
            itemsDesktopSmall: [979, $(this).attr("data-laptop")],
            itemsTablet: [768, $(this).attr("data-tablet")],
            itemsMobile: [479, $(this).attr("data-mobile")]
        })
    }), $(".shop-slider").length > 0 && $(".shop-slider").each(function() {
        var t = "true" === $(this).attr("data-auto-play") ? !0 : !1;
        $(this).owlCarousel({
            items: 1,
            loop: !0,
            mouseDrag: !0,
            navigation: !0,
            dots: !1,
            pagination: !1,
            autoPlay: t,
            autoplayTimeout: 5e3,
            autoplayHoverPause: !0,
            smartSpeed: 1e3,
            autoplayHoverPause: !0,
            navigationText: ['<i class="prev ion-ios-arrow-left"></i>', '<i class="next ion-ios-arrow-right"></i>'],
            itemsDesktop: [1199, $(this).attr("data-desktop")],
            itemsDesktopSmall: [979, $(this).attr("data-laptop")],
            itemsTablet: [768, $(this).attr("data-tablet")],
            itemsMobile: [479, $(this).attr("data-mobile")]
        })
    })
}

function makePages() {
    $.each(this.owl.userItems, function(t) {
        $(".owl-controls .owl-page").eq(t).css({
            background: "url(" + $(this).find("img").attr("src") + ")",
            "background-size": "cover"
        })
    })
}! function(t, a, e) {
    "use strict";
    e(t).on("load", function() {}), e(t).on("resize", function() {}), e(t).on("scroll", function() {
        e(t).scrollTop() >= 180 ? e("#go-to-top").addClass("on") : e("#go-to-top").removeClass("on")
    }), e(a).ready(function(t) {
        popupContent(), owlCarousel(), introHeight(), progressBar(), googleMap(), toggleMenu(), t('[data-toggle="tooltip"]').tooltip(), t(".show-features").on("click", function() {
            t(".box-features").slideToggle("slow")
        }), t(".noo-main-canvas .fa-angle-down").on("click", function() {
            t(this).siblings(".sub-menu").slideToggle("slow"), t(this).toggleClass("active")
        }), t(".blog-item.style-3").each(function() {
            t(this).find(".blog-featured").css("background-image", 'url("' + t(this).find(".blog-featured").attr("data-src") + '")')
        }), t(a).on("show.bs.collapse hide.bs.collapse", ".panel-group", function(a) {
            var e = t(a.target);
            "show" == a.type && t(".panel-heading").removeClass("active"), e.prev(".panel-heading").addClass("active"), "hide" == a.type && e.prev(".panel-heading").removeClass("active")
        }), t("body").on("click", "#go-to-top", function() {
            return t("html, body").animate({
                scrollTop: 0
            }, 800), !1
        }), t(".header-sticky").length && t(".header-sticky").headroom()
    })
}(window, document, jQuery);